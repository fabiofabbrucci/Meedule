-- MySQL dump 10.13  Distrib 5.1.50, for unknown-linux-gnu (x86_64)
--
-- Host: localhost    Database: meedule
-- ------------------------------------------------------
-- Server version	5.1.50-community-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Meeting`
--

DROP TABLE IF EXISTS `Meeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Meeting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` longtext,
  `address` longtext,
  `createdAt` datetime NOT NULL,
  `mail` varchar(255) NOT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `duration` double DEFAULT NULL,
  `slugpublic` varchar(32) NOT NULL,
  `slugprivate` varchar(32) NOT NULL,
  `name` varchar(255) NOT NULL,
  `doodle` varchar(255) DEFAULT NULL,
  `closed` tinyint(1) DEFAULT NULL,
  `closedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_3AA8D8A56474467C` (`slugpublic`),
  UNIQUE KEY `UNIQ_3AA8D8A5E8EC5077` (`slugprivate`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Meeting`
--

LOCK TABLES `Meeting` WRITE;
/*!40000 ALTER TABLE `Meeting` DISABLE KEYS */;
INSERT INTO `Meeting` VALUES (1,'Proviamo','Descrizione','Prova','2013-01-09 07:29:44','fabio.fabbrucci@gmail.com','2013-01-10','08:00:00',10,'47215cd55683c9b807053e21f327b8e8','f76d47863ec788297d2c630b2e7e8222','Fabio',NULL,NULL,'0000-00-00 00:00:00'),(2,'Proviamo',NULL,NULL,'2013-01-09 07:33:10','fabio.fabbrucci@gmail.com','2013-01-10','08:00:00',0,'75336a5a65d434661e9e810a91b512a4','689fd1d3549e6c270e66e55deb91fead','Fabiuo',NULL,NULL,'0000-00-00 00:00:00'),(3,'Assemblea Ordinaria dei Soci WEBdeBS','Convocazione assemblea ordinaria dei soci WEBdeBS.','Via Cipro 66','2013-01-09 08:16:11','info@webdebs.org','2013-01-17','20:00:00',120,'582d9cf85281147054265124e2baa048','8b0b0230bb9e6a912a9438472e0fbf64','Cristiano Rastelli',NULL,NULL,'0000-00-00 00:00:00'),(4,'Website launch','website benchmarks for inspirating customer','mumbai','2013-01-09 08:18:17','dharma@basili.co','2013-01-11','10:00:00',120,'f357fd23aa9b30177d016ea040659319','f024ebd848549b6c5cad8d68ee8d5460','dharma',NULL,NULL,'0000-00-00 00:00:00'),(5,'Riunione di cooridnamento','Prova','Acqua Liofilizzata Via Dante Alighieri, 27 Crema','2013-01-09 08:44:40','mery@acqualiofilizzata.it','2013-01-11','12:00:00',10,'4bed568977071416d6c8ee40662600f6','08dfab9ac8158917b5eb36dd443e7559','Mery',NULL,NULL,'0000-00-00 00:00:00'),(6,'Test','ASFN asòofn asòdf09i ajsdòfoina sòldfkn òasldfjg','Via rossi 324','2013-01-09 08:49:38','dsfs8dfh@pippo.it','2013-01-10','08:00:00',20,'6e3c68902c8aa79415dcf755cfd2bfae','cf4009af98d71962eb26786e81c131cb','Pippo',NULL,NULL,'0000-00-00 00:00:00'),(7,'Ne parliamo dopo',NULL,NULL,'2013-01-09 09:09:50','alberto.brandolini@gmail.com','2013-01-10','08:00:00',180,'b6bce639f258ac8ec8d2c3332ca56465','8f01907c45e8e31c1da926f112a6501e','Alberto Brandolini',NULL,NULL,'0000-00-00 00:00:00'),(8,'Riunioneggiamo','Riunione di prova',NULL,'2013-01-09 09:33:50','meedule@silvia.oib.com','2013-01-09','15:45:00',30,'9a1c84dc9d121d7b66f612f87cf520b3','a309c1051080053f55eb5033d6d57e0a','Silvia',NULL,NULL,'0000-00-00 00:00:00'),(9,'Test meeting','Bla bla bla...','Via Bla bla bla','2013-01-09 09:42:30','mavimo@gmail.com','2013-01-16','09:00:00',180,'7a6994bfce3dd7fbd9e7332470846806','2f223ee9d655f4baab13749b3962cd3d','Marco',NULL,NULL,'0000-00-00 00:00:00'),(10,'test',NULL,NULL,'2013-01-09 10:04:14','www@www.it','2013-01-14','10:30:00',30,'550fda28612c73ebaff12adf138499f2','8c4cdf36037271fd38b96c827d4617f8','www',NULL,NULL,'0000-00-00 00:00:00'),(11,'allenamento','test','in sede','2013-01-09 11:08:15','pippo@caruso.it','2013-01-10','20:00:00',60,'a17477119614e470a491a1058ccbfa0f','f19c73e8e92e32e8b6c22d06486331b8','filippo',NULL,NULL,'0000-00-00 00:00:00'),(12,'Gnpèpdsfd','xcvf',NULL,'2013-01-09 12:27:32','vhii@ik.ou','2013-01-10','12:00:00',0,'a3e3af9a23f490513a383488cf3431b1','2f2cace852162645685757bfe0125965','fdgtn',NULL,NULL,'0000-00-00 00:00:00'),(13,'Assemblea Ventoonirico','Siamo sull\'orlo di un precipizio!!! Quest\'anno dobbiamo fare un passo avanti',NULL,'2013-01-10 09:13:35','danilo.sanchi@gmail.com','2013-01-16','21:00:00',120,'3cd03a7f598ac2ac5c8e2f4acb5f09c8','c5d707ea4b2e4cb0c962a5ace7898590','Danilo',NULL,NULL,'0000-00-00 00:00:00'),(14,'riunione esempio','esempio di creazione agenda condivisa con Meedule','Sigirino','2013-01-10 12:51:43','edanese@gmail.com','2013-01-13','12:00:00',120,'ef435916d8e44aeaaa728c860ff1fac4','cb05c543ba8f064ab537bceb71f70d3b','Elisa',NULL,NULL,'0000-00-00 00:00:00'),(15,'prova','prova','milano','2013-01-10 16:04:37','momonicamo@libero.it','2013-01-11','16:00:00',10,'0473511edcbac1331bc1e5c8f643affa','6885db8863b5275625216aafc8e3cbc7','noemi',NULL,NULL,'0000-00-00 00:00:00'),(16,'prova',NULL,'milano','2013-01-10 16:11:57','valeriadicaridicari@libero.it','2013-01-11','16:00:00',10,'0d3ed2d24d179b3fdda956032052e8b5','b94e2f5b469ed139465580018e8f25b6','prova','http://doodle.com/y89wp9kasqzuaezy',NULL,'0000-00-00 00:00:00'),(17,'Meeting prova','Prova','Terzo pianeta a destra','2013-01-10 23:19:25','twinline@aol.it','2013-01-11','08:00:00',60,'8d0ce975523df927b2a4e3d64c9f882e','f3fa580d9e761816b9357a68d2d67b0c','Jack',NULL,NULL,'0000-00-00 00:00:00'),(18,'primo incontro',NULL,'faenza','2013-01-11 05:05:45','ffullone@gmail.com','2013-01-12','08:00:00',30,'0bff0457682f8105fad61cd0b9a32fd8','bd285f1882ae17a1625f860c7fbbe3aa','fullo',NULL,NULL,'0000-00-00 00:00:00'),(19,'prova prova','decisione pranzo domenicale','soggiorno','2013-01-11 13:34:30','fogliaandrea@yahoo.com','2013-01-12','13:00:00',10,'5b32fd4449eb7b97a381d45d8dfb28f4','c4c871b212237eb10cf0d88ed3b3f92a','andrea',NULL,NULL,'0000-00-00 00:00:00'),(20,'dfgdfgdfg','dfgdfg','sdfsdgf','2013-01-12 09:44:42','utentemain2@libero.ite','2013-01-13','09:00:00',30,'d9756c40508e790090cdf4b010c25580','fc9b2d7ece13e1c5becacc04e80affc4','utentemain2',NULL,NULL,'0000-00-00 00:00:00'),(21,'Prova',NULL,NULL,'2013-01-15 11:40:04','fabio.fabbrucci@gmail.com','2013-01-16','11:00:00',0,'aaee91fe19cd99f43bda274db1552bef','13bfdf28a772d2678bd7558d0c803346','Fabio',NULL,NULL,NULL),(22,'Riunione di quartiere',NULL,'Osimo','2013-01-15 12:32:37','francesco@trucchia.it','2013-01-16','12:00:00',60,'9070438e25627e24a605f6e3dd35d924','1cf6b74bbbebddb9267cac0193de97d3','Francesco Trucchia',NULL,NULL,NULL),(23,'Prova',NULL,NULL,'2013-01-15 12:37:27','fabio.fabbrucci@gmail.com','2013-01-16','12:00:00',0,'4bd31c49d2d6379868c5ee2685e2894d','194f72fa66d76c7bc77050c190c87b76','Fabio',NULL,NULL,NULL),(24,'Birra da qualche parte','Nessuna','Cagliari','2013-01-15 14:48:33','sulis.mtt@gmail.com','2013-01-18','21:00:00',180,'0a3b4470bcfb4035a7b49192a4a15b6d','7be19e6f8f9629019d6cc7eb682dc82f','Matteo Sulis',NULL,NULL,NULL),(25,'Test Jacopo','hjghjkgghjkghjkgkjhg lorem ipsum','Milano, Piazza Piola','2013-01-15 16:36:28','jromei@gmail.com','2013-01-18','16:00:00',20,'e4ae8e6d452dc8bf80a88e7377f3a2fc','9dc7e2b8e11bd08ac43cba71120064fa','Jacopo Romei',NULL,NULL,NULL),(26,'Assemblea ordinaria dei soci','I soci possono partecipare all’Assemblea personalmente oppure, se impossibilitati, a mezzo delega di altro socio; la delega, firmata dal delegante, deve riportare gli estremi dell’Assemblea, la data e il nome del delegato, e può essere presentata direttamente dal socio delegato oppure inviata a mezzo posta ordinaria o fax alla segreteria dell’Associazione. Ciascun socio può essere portatore di una sola delega; non è ammesso il voto per corrispondenza. Tutti i soci hanno diritto di voto.','Brescia, Via Cipro 66','2013-01-16 05:33:36','info@didoo.net','2013-01-17','20:00:00',120,'8713cda043ac8aa4ae2b56ce2e08ea36','8a21519789f98db003a1dc02f552266c','Cristiano Rastelli',NULL,NULL,NULL),(27,'test',NULL,NULL,'2013-01-16 10:23:27','gianmarco.antonelli@gmail.com','2013-01-17','10:00:00',10,'c0f2d14613a2fbe0a2dd3503bca5a5e1','db9a8663239e3b0bcfb77c569a0ad746','ga',NULL,NULL,NULL),(28,'Assemblea Soci',NULL,'Ospedale Infermi Rimini, Aula G','2013-01-16 12:04:21','zucchino@drclown.it','2013-02-27','20:45:00',120,'9a0b4c10ee90ab4e9209e8abc89fce48','c7a21449c197399c8d99b3617efd720d','Fabio Fabbrucci',NULL,NULL,NULL),(29,'Direttivo 25 gennaio',NULL,'Palestra della Sonia','2013-01-17 04:30:06','zucchino@drclown.it','2013-01-25','21:00:00',30,'0436bf2e34cc1cae3ebc724f10d89d65','514d7aefceac5753c418282d1e56bc66','Fabio',NULL,NULL,NULL),(30,'Direttivo 30 gennaio',NULL,'Da Sonia o Spasso','2013-01-17 04:32:57','zucchino@drclown.it','2013-01-30','21:00:00',180,'746a3fbd85288fd9a0434d7ab7b25cc2','4f32134a9d3c23a7c7bc2dd110e0edd3','Fabio',NULL,NULL,NULL),(31,'lll','ff','ff','2013-01-20 07:38:23','pippo@mailinator.com','2013-01-21','08:00:00',10,'e3527e8ba2c5df39c5a59b6073418f0b','c3676b4d4269baef14526a68656a3f62','dm',NULL,NULL,NULL);
/*!40000 ALTER TABLE `Meeting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Reference`
--

DROP TABLE IF EXISTS `Reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Reference` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `meeting_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `owner` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_2C52CBB067433D9C` (`meeting_id`),
  CONSTRAINT `FK_2C52CBB067433D9C` FOREIGN KEY (`meeting_id`) REFERENCES `Meeting` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Reference`
--

LOCK TABLES `Reference` WRITE;
/*!40000 ALTER TABLE `Reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `Reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Topic`
--

DROP TABLE IF EXISTS `Topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Topic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `meeting_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `approved` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_5C81F11F67433D9C` (`meeting_id`),
  CONSTRAINT `FK_5C81F11F67433D9C` FOREIGN KEY (`meeting_id`) REFERENCES `Meeting` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Topic`
--

LOCK TABLES `Topic` WRITE;
/*!40000 ALTER TABLE `Topic` DISABLE KEYS */;
INSERT INTO `Topic` VALUES (1,1,'Prova',2,NULL,NULL),(2,1,'Infine',1,NULL,NULL),(3,3,'Relazione attività 2012',1,NULL,NULL),(4,3,'Proposta di approvazione bilancio consuntivo 2012 e bilancio preventivo 2013',2,NULL,NULL),(5,3,'Definizione attività e obiettivi 2013',3,NULL,NULL),(6,3,'Varie ed eventuali.',4,NULL,NULL),(7,4,'eamples',1,NULL,NULL),(8,4,'benchmarks',2,NULL,NULL),(9,4,'budget',3,NULL,NULL),(10,4,'timing',4,NULL,NULL),(11,4,'test',1,'doug',NULL),(13,5,'Stato Lavori 5a',1,NULL,NULL),(14,5,'Stato lavori MadeUp',2,NULL,NULL),(15,6,'Prova',1,NULL,NULL),(16,7,'La piadina',1,NULL,NULL),(17,7,'La salciccia',2,NULL,NULL),(18,7,'la cipolla',3,NULL,NULL),(19,7,'Lo squaquerone',1,'Brando',NULL),(20,7,'La rucola',2,'Aribrando',NULL),(21,8,'primo argomento',1,NULL,NULL),(22,8,'secondo test',2,NULL,NULL),(23,8,'conclusioni',3,NULL,NULL),(24,9,'Primo punto all\'OdG',1,NULL,NULL),(25,9,'Parliamone',1,'Fabio',NULL),(26,10,'err',1,NULL,NULL),(27,10,'wert',2,NULL,NULL),(28,10,'ewtewtew',3,NULL,NULL),(29,11,'Allenamento duro',1,NULL,NULL),(30,11,'riposo leggero',2,NULL,NULL),(31,11,'non fare l\'allenamento',1,'io',NULL),(32,12,'Equicalor',1,NULL,NULL),(33,12,'Equicalor Evolution',2,NULL,NULL),(37,13,'Gestione dei giochi',6,NULL,NULL),(38,13,'Associazione o club',4,NULL,NULL),(39,13,'Rapporto con Tassello mancante',2,NULL,NULL),(40,13,'Pagamento riscaldamento della sede',3,NULL,NULL),(41,13,'Pulizia della sede e organizzazione',1,NULL,NULL),(42,13,'Alternativa del Bagus (martedì sera)',7,NULL,NULL),(43,13,'Alternativa dei Goblins (giovedì sera)',8,NULL,NULL),(44,13,'Vedersi in casa',5,NULL,NULL),(45,14,'mangiare e bere',1,NULL,NULL),(46,14,'test',2,NULL,NULL),(47,14,'bla bla bla',3,NULL,NULL),(48,14,'elezioni a pippolandia',1,'Pippo',NULL),(49,15,'prova',1,NULL,NULL),(50,16,'provva',1,NULL,NULL),(51,17,'Arg 1',1,NULL,NULL),(52,17,'Arg2',2,NULL,NULL),(53,18,'cose',1,NULL,NULL),(54,18,'persone',2,NULL,NULL),(55,18,'città',3,NULL,NULL),(56,19,'pranzo',1,NULL,NULL),(57,19,'antipoasto',2,NULL,NULL),(58,20,'aaaaaaa',1,NULL,NULL),(59,21,'Prova',1,NULL,NULL),(60,21,'Unaltro',2,NULL,NULL),(61,21,'Ppp',3,NULL,NULL),(62,21,'Questo',1,'Fabio',NULL),(63,22,'Tema 1',1,NULL,NULL),(64,22,'Tema 2',2,NULL,NULL),(65,23,'arg21',1,NULL,NULL),(66,22,'Bidoni all\'angolo',1,'Fabio',NULL),(67,24,'Degustare bevande',1,NULL,NULL),(68,25,'Il tortello a confronto con il cappelletto',1,NULL,NULL),(69,25,'Blur vs. Oasis',2,NULL,NULL),(70,25,'Cappelletto o passatello?',1,'Fabio Fabbrucci',NULL),(71,26,'Relazione attività del 2012',1,NULL,NULL),(72,26,'Proposta di approvazione bilancio consuntivo 2012 e bilancio preventivo 2013',2,NULL,NULL),(73,26,'Definizione attività e obiettivi 2013',3,NULL,NULL),(74,26,'Varie ed eventuali.',4,NULL,NULL),(75,28,'Approvazione bilancio 2012',1,NULL,NULL),(76,28,'Presentazione schema di valutazione',2,NULL,NULL),(77,28,'Presentazione nuovo schema di formazione e turni',3,NULL,NULL),(78,29,'Situazione convegno',1,NULL,NULL),(79,29,'Bilancio 2012',2,NULL,NULL),(80,30,'Definitivo Formazione',1,NULL,NULL),(81,30,'Definitivo Bilancio',2,NULL,NULL),(82,31,'ss',1,NULL,NULL);
/*!40000 ALTER TABLE `Topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `meeting_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `mail` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_2DA1797767433D9C` (`meeting_id`),
  CONSTRAINT `FK_2DA1797767433D9C` FOREIGN KEY (`meeting_id`) REFERENCES `Meeting` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES (1,4,'dharma',''),(2,4,'michele',''),(3,4,'pat',''),(4,4,'naqisa',''),(5,8,'Giovanni',''),(7,9,'Fabio',''),(8,11,'io',''),(9,13,'Danilo',''),(10,13,'Mirco (parto permettendo)',''),(12,14,'Elisa',''),(13,14,'pippo',''),(14,15,'noemi',''),(15,15,'valeria',''),(16,16,'prova',''),(17,17,'Jack',''),(18,17,'Jack',''),(19,18,'fullo',''),(20,18,'Fabio',''),(21,19,'andrea',''),(22,20,'utentemain2',''),(23,21,'Fabio','fabio.fabbrucci@gmail.com'),(25,22,'Francesco Trucchia','francesco@trucchia.it'),(26,23,'Fabio','fabio.fabbrucci@gmail.com'),(27,22,'Fabio Fabbrucci','fabio.fabbrucci@gmail.com'),(28,24,'Matteo Sulis','sulis.mtt@gmail.com'),(29,25,'Jacopo Romei','jromei@gmail.com'),(30,26,'Cristiano Rastelli','info@didoo.net'),(31,28,'Fabio Fabbrucci','zucchino@drclown.it'),(32,29,'Fabio','zucchino@drclown.it'),(33,30,'Fabio','zucchino@drclown.it'),(34,28,'Dr Spasso','drspasso@gmail.com'),(35,31,'dm','pippo@mailinator.com');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ext_log_entries`
--

DROP TABLE IF EXISTS `ext_log_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ext_log_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(8) NOT NULL,
  `logged_at` datetime NOT NULL,
  `object_id` varchar(32) DEFAULT NULL,
  `object_class` varchar(255) NOT NULL,
  `version` int(11) NOT NULL,
  `data` longtext COMMENT '(DC2Type:array)',
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `log_class_lookup_idx` (`object_class`),
  KEY `log_date_lookup_idx` (`logged_at`),
  KEY `log_user_lookup_idx` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ext_log_entries`
--

LOCK TABLES `ext_log_entries` WRITE;
/*!40000 ALTER TABLE `ext_log_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `ext_log_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ext_translations`
--

DROP TABLE IF EXISTS `ext_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ext_translations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `locale` varchar(8) NOT NULL,
  `object_class` varchar(255) NOT NULL,
  `field` varchar(32) NOT NULL,
  `foreign_key` varchar(64) NOT NULL,
  `content` longtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lookup_unique_idx` (`locale`,`object_class`,`foreign_key`,`field`),
  KEY `translations_lookup_idx` (`locale`,`object_class`,`foreign_key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ext_translations`
--

LOCK TABLES `ext_translations` WRITE;
/*!40000 ALTER TABLE `ext_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `ext_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migration_versions`
--

DROP TABLE IF EXISTS `migration_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migration_versions` (
  `version` varchar(255) NOT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migration_versions`
--

LOCK TABLES `migration_versions` WRITE;
/*!40000 ALTER TABLE `migration_versions` DISABLE KEYS */;
INSERT INTO `migration_versions` VALUES ('20130105172845'),('20130105174916'),('20130105175215'),('20130105175412'),('20130105180738'),('20130107110110'),('20130107110252'),('20130107110440'),('20130107111130'),('20130107120839'),('20130107165751'),('20130107170411'),('20130110154218'),('20130110162553'),('20130111121325'),('20130115144105'),('20130115145942'),('20130115170729'),('20130115171700'),('20130115175635'),('20130115181343');
/*!40000 ALTER TABLE `migration_versions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-01-21  8:41:22
